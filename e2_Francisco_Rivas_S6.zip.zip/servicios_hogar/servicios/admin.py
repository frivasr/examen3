from django.contrib import admin
from .models import TipoServicio, SolicitudServicio

admin.site.register(TipoServicio)
admin.site.register(SolicitudServicio)